Stationery Inventory Management System (Java Swing)
Requires JDK 8+.

Compile:  javac -encoding UTF-8 -d out src/inventory/*.java
Run:      java -cp out inventory.Main

Data is saved automatically to stationery_inventory.dat in the folder you run from.
